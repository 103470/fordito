﻿using System.Diagnostics;

namespace fordito
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string content = null;
            sourceHandler s1 = new sourceHandler("C:\\Users\\Martin\\source\\repos\\fordito\\fordito\\bin\\Debug\\net6.0\\be.txt", "C:\\Users\\Martin\\source\\repos\\fordito\\fordito\\bin\\Debug\\net6.0\\ki.txt", "C: \\Users\\Martin\\source\\repos\\fordito\\fordito\\bin\\Debug\\net6.0\\content.txt");

            s1.OpenRead();
            s1.singleReplace();
            s1.openContent();
            s1.replaceComment();
            s1.OpenToWrite();
        }
    }
}