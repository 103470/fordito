﻿using System.Collections.Specialized;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string content = null;
            sourceHandler s1 = new sourceHandler("C:\\Users\\user\\Documents\\ssr0ti\\ConsoleApp1\\bin\\Debug\\net6.0\\be.txt", "C:\\Users\\user\\Documents\\ssr0ti\\ConsoleApp1\\bin\\Debug\\net6.0\\ki.txt", "C:\\Users\\user\\Documents\\ssr0ti\\ConsoleApp1\\bin\\Debug\\net6.0\\content.txt");
            

            s1.OpenRead();
            s1.singleReplace();
            s1.replaceContent();
            s1.OpenToWrite();

            regex0 R = new regex0("signedfloatnumbers");
            string data = "-4.0";
            Console.WriteLine("A regex eredménye a {0} stringre = {1}", data, R.match(data));

            List<string> l = R.matches("alm alma alma 12 alma +24 alma");
            foreach(var x in l)
            {
                Console.WriteLine(x);
            }
            Console.WriteLine(R.replace("alma alma +24 alma +42", "NUMBER"));


            recModell r = new recModell();
            r.input = "v+(v*v)#";
            r.S();

            //Console.WriteLine(R.match());
            Console.ReadKey();

        }
    }
}