﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string content = null;
            sourceHandler s1 = new sourceHandler("C:\\Users\\user\\Documents\\ssr0ti\\ConsoleApp1\\bin\\Debug\\net6.0\\be.txt", "C:\\Users\\user\\Documents\\ssr0ti\\ConsoleApp1\\bin\\Debug\\net6.0\\ki.txt", "C:\\Users\\user\\Documents\\ssr0ti\\ConsoleApp1\\bin\\Debug\\net6.0\\content.txt");
            

            s1.OpenRead();
            s1.singleReplace();
            s1.replaceContent();
            s1.OpenToWrite();

            regex0 R = new regex0("q0", "d2d2");
            
            Console.WriteLine(R.match());
            Console.ReadKey();

        }
    }
}