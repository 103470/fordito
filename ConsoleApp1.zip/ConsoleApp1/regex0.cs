﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class regex0
    {
        public string all;
        public string input;
        char digits = 'd';
        char letters = 'l';

        
        // temporary function
        char convert(char c)
        {
            if (char.IsDigit(c))
            {
                return digits;
            }
            if (char.IsLetter(c))
            {
                return letters;
            }

            return c;
        }

        Dictionary<string, string> statemants = new Dictionary<string, string>();

        public regex0(string all, string input)
        {
            this.all = all;
            this.input = input;
            statemants.Add("firststate", "q0");
            //statemants.Add("finalstate", "q2");
            //statemants.Add("finalstate", "q2q3");
            statemants.Add("finalstate", "q1q2");
            statemants.Add("errstate", "err");

            statemants.Add("q0l", "q1");
            statemants.Add("q1d", "q1");
            statemants.Add("q1l", "q1");
            statemants.Add("q1_", "q2");
            statemants.Add("q2d", "q1");
            statemants.Add("q2l", "q1");




            /*statemants.Add("qx-", "q0");
            statemants.Add("qx+", "q0");
            statemants.Add("qx.", "q1");
            statemants.Add("qxd", "q2");
            statemants.Add("q0.", "q1");
            statemants.Add("q1d", "q3");
            statemants.Add("q3d", "q3");
            statemants.Add("q0d", "q2");
            statemants.Add("q2d", "q2");
            statemants.Add("q2.", "q3");*/

            /*statemants.Add("q0-", "q1");
            statemants.Add("q0+", "q1");
            statemants.Add("q0d", "q2");
            statemants.Add("q1d", "q2");
            statemants.Add("q2d", "q2");*/
        }

        string delta(string a, char c)
        {
            string st = a + convert(c);
            if(statemants.ContainsKey(st))
            {
                return statemants[st];
            }

            return statemants["errstate"];
            // "q0d" "q0-" "q0+"
            /*switch(a + convert(c))
            {
                case "q0-": return "q1";
                case "q0+": return "q1";
                case "q0d": return "q2";
                case "q1d": return "q2";
                case "q2d": return "q2";
                default: return "err";
            }
            */

            
        }

        public bool match()
        {
            this.all = statemants["firststate"];
            int i = 0;
            while(i<input.Length && all != statemants["errstate"])
            {
                all = delta(all, input[i]);
                i++;
            }
            if(all == statemants["errstate"] || all != statemants["finalstate"])
            {
                return false;
            }
            return true;
        }

        

    }
}
