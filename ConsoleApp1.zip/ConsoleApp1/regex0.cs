﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class regex0
    {
        public string all;
        public string input;
        char digits = 'd';
        char letters = 'l';

        
        // temporary function
        char convert(char c)
        {
            if (char.IsDigit(c))
            {
                return digits;
            }
            if (char.IsLetter(c))
            {
                return letters;
            }

            return c;
        }

        Dictionary<string, string> statemants = new Dictionary<string, string>();
        Dictionary<string, string> simplevariables = new Dictionary<string, string>
        {
            {"firststate", "q0" },
            {"finalstate", "q1" },
            {"errstate", "err" },
            {"q0l", "q1" },
            {"q1l", "q1" },
            {"q1d", "q1" }


        };
        Dictionary<string, string> variables = new Dictionary<string, string>
        {
            {"firststate", "q0" },
            {"finalstate", "q1q2" },
            {"errstate", "err" },
            {"q0l", "q1" },
            {"q1l", "q1" },
            {"q1d", "q1" },
            {"q1_", "q2" },
            {"q2d", "q1" },
            {"q2l", "q1" },

        };
        Dictionary<string, string> signednumbers = new Dictionary<string, string>
        {
            {"firststate", "q0" },
            {"finalstate", "q2" },
            {"errstate", "err" },
            {"q0-", "q1" },
            {"q0+", "q1" },
            {"q0d", "q2" },
            {"q1d", "q2" },
            {"q2d", "q2" }
        };
        Dictionary<string, string> floatnumbers = new Dictionary<string, string>
        {
            {"firststate", "q0" },
            {"finalstate", "q2q3" },
            {"errstate", "err" },
            {"q0.", "q1"},
            {"q0d", "q2"},
            {"q2d", "q2"},
            {"q2.", "q3"},
            {"q3d", "q3"},
            {"q1d", "q3"}
        };
        Dictionary<string, string> signedfloatnumbers = new Dictionary<string, string>
        {
            {"firststate", "qx" },
            { "finalstate", "q2q3" },
            {"errstate", "err" },
            {"qx-", "q0" },
            {"qx+", "q0"},
            {"qx.", "q1"},
            {"qxd", "q2"},
            {"q0.", "q1"},
            {"q0d", "q2"},
            {"q2d", "q2"},
            {"q2.", "q3"},
            {"q1d", "q3"},
            {"q3d", "q3"}
        };



        public regex0(string regexType)
        {
            switch (regexType)
            {
                case "variables": statemants = variables; break;
                case "simplevariables": statemants = simplevariables; break;
                case "signednumbers": statemants = signednumbers; break;
                case "floatnumbers": statemants = floatnumbers; break;
                case "signedfloatnumbers": statemants = signedfloatnumbers; break;
                default: throw new Exception("Unknown regex type received");


            }
        }


        /*public regex0(string all, string input)
        {
            this.all = all;
            this.input = input;
            statemants.Add("firststate", "q0");
            //statemants.Add("finalstate", "q2");
            //statemants.Add("finalstate", "q2q3");
            statemants.Add("finalstate", "q1q2");
            statemants.Add("errstate", "err");

            statemants.Add("q0l", "q1");
            statemants.Add("q1d", "q1");
            statemants.Add("q1l", "q1");
            statemants.Add("q1_", "q2");
            statemants.Add("q2d", "q1");
            statemants.Add("q2l", "q1");
            




            statemants.Add("qx-", "q0");
            statemants.Add("qx+", "q0");
            statemants.Add("qx.", "q1");
            statemants.Add("qxd", "q2");
            statemants.Add("q0.", "q1");
            statemants.Add("q1d", "q3");
            statemants.Add("q3d", "q3");
            statemants.Add("q0d", "q2");
            statemants.Add("q2d", "q2");
            statemants.Add("q2.", "q3");

            statemants.Add("q0-", "q1");
            statemants.Add("q0+", "q1");
            statemants.Add("q0d", "q2");
            statemants.Add("q1d", "q2");
            statemants.Add("q2d", "q2");
        }
        */

        string delta(string a, char c)
        {
            string st = a + convert(c);
            if(statemants.ContainsKey(st))
            {
                return statemants[st];
            }

            return statemants["errstate"];
            // "q0d" "q0-" "q0+"
            /*switch(a + convert(c))
            {
                case "q0-": return "q1";
                case "q0+": return "q1";
                case "q0d": return "q2";
                case "q1d": return "q2";
                case "q2d": return "q2";
                default: return "err";
            }
            */

            
        }
        bool finalStates(string state)
        {
            if (statemants["finalsatate"].Contains(state))
            {
                return true;
            }
            return false;
        }

        public bool match(string input)
        {
            this.all = statemants["firststate"];
            int i = 0;
            while(i<input.Length && all != statemants["errstate"])
            {
                all = delta(all, input[i]);
                i++;
            }
            
           if (all == statemants["errstate"] || !finalStates(all))
            {
                return false;
            }
            return true;
        }

        public List<string> matches(string source)
        {
            List<string> matchCollection = new List<string>();
            string[] elements = source.Split(" ");
            foreach(var x in elements)
            {
                if (match(x))
                {
                    matchCollection.Add(x);
                }
            }
            return matchCollection;
        }

        public string replace(string source, string r)
        {
            string data = "";
            string[] elements = source.Split(' ');
            for(int i = 0; i < elements.Length; i++)
            {
                if (match(elements[i]))
                {
                    elements[i] = r;
                }
                data += elements[i] + " ";
            }
            return data;
        }

        

    }
}
