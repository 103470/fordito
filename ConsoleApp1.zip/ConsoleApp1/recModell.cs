﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class recModell
    {
        public string input;
        int index = 0;

        void accept(char symbol)
        {
            if (input[index] == symbol)
            {
                index++;
            }
            else
            {
                //TODO: error fv. megírása!
                Console.WriteLine("Hiba itt {0}", index);
            }
        }

            public void S()
            {
                E();
                accept('#');
                //TODO: Kezelni kell az eredményt!
                Console.WriteLine("Az elemzés lefutott");
            }

            void E()
            {
                T();
                Ev();
            }

            void Ev()
            {
                if (input[index] == '+')
                {
                    accept('+');
                    T();
                    Ev();
                } //nincs else ág az epszilon miatt
                

            }

            void T()
            {
                F();
                Tv();
            }

            void Tv()
            {
                if (input[index] == '*')
                {
                    accept('*');
                    F();
                    Tv();
                } //nincs else ág az epszilon miatt
            }

            void F()
            {
                if (input[index] == '(')
                {
                    accept('(');
                    E();
                    accept(')');
                   
                }
                else
                {
                    accept('v');
                }
            }


        
    }
}
